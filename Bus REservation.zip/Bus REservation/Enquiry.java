import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.geom.*;

class Enquiry extends Connect implements ActionListener
{
int count=0;
JFrame f;
JLabel l1,l2;
JTextField t;




JButton b1,b2;
PreparedStatement ps;
ResultSet rs;
JLabel imgL;
ImageIcon img; 
String user;
Enquiry(String s)
{
user=s;
img=new ImageIcon("high2.png");
imgL=new JLabel(img);
imgL.setBounds(0,0,1300,768);

f=new JFrame("PNR-Enquiry");
f.getContentPane().setLayout(null);
f.getContentPane().setBackground(Color.black);

l1=new JLabel("PNR No");
l1.setFont(new Font("Arial",(Font.BOLD),30));
l1.setForeground(Color.red);
l1.setBounds(50,55,200,50);
/*
l2=new JLabel("PNR Details");
l2.setFont(new Font("Arial",(Font.BOLD),30));
l2.setForeground(Color.red);
l2.setBounds(50,100,200,50);
*/


t=new JTextField(10);
t.addActionListener(this);
t.setFont(new Font("Arial",(Font.BOLD),20));
t.setBackground(Color.lightGray);
t.setBounds(180,55,260,50);






b1=new JButton("Check");
b1.setBackground(Color.darkGray);
b1.setForeground(Color.white);
b1.addActionListener(this);
b1.setBounds(90,250,100,50);
b1.setBorder(new RoundedBorder(30));

b2=new JButton("Back");
b2.setBackground(Color.darkGray);
b2.setForeground(Color.white);
b2.addActionListener(this);
b2.setBounds(270,250,100,50);
b2.setBorder(new RoundedBorder(30));

b1.setMnemonic('C');
b2.setMnemonic('B');

f.add(l1);
//f.add(l2);
f.add(t);

f.add(b1);
f.add(b2);

f.add(imgL);
f.setSize(1300,1000);
f.setVisible(true);

}






public void actionPerformed(ActionEvent e)
{
String [][] data= new String[20][10];
String [] column={"Name","Age","Category","Train No.","Train Name","Class","Bording At","Date","Seat No.","Status"};

if(t.getText().length()!=0&&e.getSource()==b1)
{
try
{
ps=con.prepareStatement("select * from details where PNR_No='"+t.getText()+"'");
rs=ps.executeQuery();

while(rs.next())
{
count++;






/*
t1.append(count+". ");
t1.append(rs.getString("Name")+"\t");
t1.append(rs.getString("Age")+"\t");
t1.append(rs.getString("Category")+"\t");
t1.append(rs.getString("Train_No")+"\t");
t1.append(rs.getString("Train_Name")+"  ");
t1.append(rs.getString("Class")+"\t");
t1.append(rs.getString("Boarding_At")+"\t");
t1.append(rs.getString("Date")+"\n");
*/




data[count-1][0]=rs.getString("Name");
data[count-1][1]=rs.getString("Age");
data[count-1][2]=rs.getString("Category");
data[count-1][3]=rs.getString("Train_No");
data[count-1][4]=rs.getString("Train_Name");
data[count-1][5]=rs.getString("Class");
data[count-1][6]=rs.getString("Boarding_At");
data[count-1][7]=rs.getString("Date");
data[count-1][8]=Integer.toString(rs.getInt("Seat_No"));
data[count-1][9]=rs.getString("Status");







/*rs.next();
t1.clear();
t1.add("Train Number.: "+rs.getString(2));
t1.add("Train Name: "+rs.getString(3));
t1.add("Class: "+rs.getString(4));
t1.add("Date of Journey: "+rs.getString(5));
t1.add("From: "+rs.getString(6));
t1.add("To: "+rs.getString(7));
t1.add("Boarding at: "+rs.getString(8));
*/
}


new Table(column,data);

/*else
{
t1.setText(""); 
JOptionPane.showMessageDialog(null,"Invalid PNR number");
}*/

}
catch(Exception e1)
{
System.out.println("connection failed:"+e1);
}
}

if(e.getSource()==b2)
{
f.setVisible(false);
new Main(user);
}
}

class RoundedBorder implements Border 
{
int radius;
RoundedBorder(int radius) 
{
this.radius = radius;
}
public Insets getBorderInsets(Component c) {
return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
}
public boolean isBorderOpaque() {
return true;
}
public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
g.drawRoundRect(x,y,width-1,height-1,radius,radius);
}
}

public static void main(String args[])
{
new Enquiry("admin");
}
}