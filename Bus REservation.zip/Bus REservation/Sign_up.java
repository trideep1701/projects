import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class Sign_up extends Connect implements ActionListener
{
JLabel l1,l2,l3,l4,l5,l6,l7;
JTextField t1,t4,t5;
JPasswordField t2,t3;
JButton b1,b2,b3;
JLabel imgl;
ImageIcon img;
PreparedStatement ps;
Statement st;
ResultSet rs;
String str; 
JFrame f;
Sign_up()
{
img=new ImageIcon("sign_up.png");
imgl=new JLabel(img);
imgl.setBounds(0,0,1366,768);
f=new JFrame("Sign_up");
f.setLayout(null);
l1=new JLabel("Username");
l1.setForeground(Color.red);
l1.setBounds(800,100,100,40);
l1.setFont(new Font("Cooper",Font.BOLD,20));
l2=new JLabel("Password");
l2.setForeground(Color.red);
l2.setBounds(800,150,100,40);
l2.setFont(new Font("Cooper",Font.BOLD,20));
l3=new JLabel("Confirm Password");
l3.setForeground(Color.red);
l3.setBounds(715,200,200,40);
l3.setFont(new Font("Cooper",Font.BOLD,20));
l4=new JLabel("Captcha");
l4.setForeground(Color.red);
l4.setBounds(815,250,100,40);
l4.setFont(new Font("Cooper",Font.BOLD,20));
l5=new JLabel("DOB");
l5.setForeground(Color.red);
l5.setBounds(850,300,100,40);
l5.setFont(new Font("Cooper",Font.BOLD,20));
l7=new JLabel("(dd-mm-yyyy)");
l7.setForeground(Color.red);
l7.setBounds(1000,300,170,40);
l7.setFont(new Font("Cooper",Font.BOLD,20));
t1=new JTextField();
t1.setBounds(900,100,100,30);
t2=new JPasswordField();
t2.setEchoChar('*');
t2.setBounds(900,150,100,30);
t3=new JPasswordField();
t3.setEchoChar('*');
t3.setBounds(900,200,100,30);
 t4=new JTextField();
t4.setBounds(900,250,100,30);
t5=new JTextField();
t5.setBounds(900,300,100,30);
b1=new JButton("Confirm");
b1.setBounds(780,370,100,40);
b2=new JButton("Cancel");
b2.setBounds(900,370,100,40);
b3=new JButton("Back");
b3.setBounds(1020,370,100,40);
str="";
int y;
for(int x=0;x<6;x++)
{
if((x%2)==0)
y=65+(int)(Math.random()*26);
else
y=48+(int)(Math.random()*10);
str=str+(char)y;
}
l6=new JLabel(str);//A JLabel object can display either text, an image, or both
l6.setBounds(1020,250,100,40);
l6.setForeground(Color.red);
l6.setFont(new Font("Cooper",Font.BOLD,20));
f.add(l1);
f.add(l2);
f.add(l3);
f.add(l4);
f.add(l5);
f.add(l6);
f.add(l7);
f.add(t1);
f.add(t2);
f.add(t3);
f.add(t4);
f.add(t5);
f.add(b1);
f.add(b2);
f.add(b3);
f.add(imgl);
b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
f.setSize(1366,768);
f.setVisible(true);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{
if(t1.getText().length()!=0&&t2.getText().length()!=0)
b1.setEnabled(true);
try{
ps=con.prepareStatement("select * from sign_up where Username='"+t1.getText()+"'");
rs=ps.executeQuery();
if(!(t2.getText().equals(t3.getText())))
{
JOptionPane.showMessageDialog(null,"Password does not match.Please Try Again !!");
}
else
{
if(rs.next())
{
JOptionPane.showMessageDialog(null,"Username is already exit");
}
else if(!(t4.getText().equals(str)))
{
JOptionPane.showMessageDialog(null,"Invalid Captcha ");/*JOptionPane makes it easy to pop up a standard dialog box that prompts users for a value
 or informs them of something*\
}
else
{
ps=con.prepareStatement("insert into sign_up values(?,?,?)");
ps.setString(1,t1.getText());
ps.setString(2,t2.getText());
ps.setString(3,t5.getText());
ps.executeUpdate();
Main M=new Main(t1.getText());
ps.close();
f.setVisible(false);
}
}

}
catch(Exception e1)
{
System.out.println("Connection failed"+e1);
}

}
if(ae.getSource()==b2)
{
f.setVisible(false);
System.exit(0);
}

if(ae.getSource()==b3)
{
f.setVisible(false);
Login l=new Login();
}
}
}