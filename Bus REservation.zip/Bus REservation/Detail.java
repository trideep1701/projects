import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class Detail extends Connect implements ActionListener
{
JFrame f;
JLabel l1,l2,l3,l4,l5;
JTextField t1,t2;
JPasswordField t3;
JButton b1,b2;
Login l;
ImageIcon image;
PreparedStatement ps;
ResultSet rs;
Statement s;
Detail()
{
image=new ImageIcon("circle2.png");
l5=new JLabel(image);
l5.setBounds(0,0,1366,768);
f=new JFrame("Details");
f.setLayout(null);
l1=new JLabel("Username");
l1.setBounds(100,100,100,40);
l2=new JLabel("DOB");
l2.setBounds(100,150,100,40);
l3=new JLabel("(dd-mm-yyyy)");
l3.setBounds(320,150,100,40);
l4=new JLabel("New Password");
l4.setBounds(100,200,100,40);
t3=new JPasswordField();
t3.setBounds(200,220,100,40);
t3.setEchoChar('*');
t1=new JTextField();
t1.setBounds(200,100,100,40);
t2=new JTextField();
t2.setBounds(200,150,100,40);
b1=new JButton("Confirm");
b1.setBounds(200,280,100,40);
b2=new JButton("Back");
b2.setBounds(320,280,100,40);
f.add(l1);
f.add(l2);
f.add(l3);
f.add(l4);
f.add(t1);
f.add(t2);
f.add(t3);
f.add(b1);
f.add(b2);
f.add(l5);
b1.addActionListener(this);
b2.addActionListener(this);
f.setSize(1366,768);
f.setVisible(true);
}
public void actionPerformed(ActionEvent ae)//we can use button action listener it calls the action performed event directly
{
if(ae.getSource()==b1)
{
if(t1.getText().length()!=0&&t2.getText().length()!=0&&t3.getText().length()!=0)
b1.setEnabled(true);
try
{
ps=con.prepareStatement("select * from sign_up where Username='"+t1.getText()+"'");
rs=ps.executeQuery();
if(rs.next())
{
ps=con.prepareStatement("update sign_up set Password ='"+t3.getText()+"' where Username='"+t1.getText()+"' and DOB='"+t2.getText()+"'"); 
ps.executeUpdate();
ps.close();
f.setVisible(false);
Main m=new Main(t1.getText());
}
else
{
JOptionPane.showMessageDialog(null,"Username does not exist");
}
}
catch(Exception e1)
{
System.out.println("Connection Failed"+e1);
}
}
if(ae.getSource()==b2)
{
f.setVisible(false);//setVisible( false ) hides a Component by marking it as invisible.
l=new Login();
}
} 
}