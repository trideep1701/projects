 import java.awt.*;/* awt is platform dpendent whereas swing is platform independent,swing is advanced features all the button are drawn from swing*\
//Java AWT (Abstract Windowing Toolkit) is an API to develop GUI or window-based application in java.
import java.awt.geom.*;/*Provides the Java 2D classes for defining and performing operations on objects related to two-dimensional geometry.*\
import java.awt.event.*;/*the event subpackage is imported but it classes are not opened so this package is used*\
import javax.swing.*;.
import javax.swing.border.*;
import java.sql.*;//Provides the API for accessing and processing data stored in a data source (usually a relational database) using the JavaTM programming language
class Main extends Connect implements ActionListener/*The class that is interested in processing an action event implements this interface, and the object created with 
that class is registered with a component, using the component's addActionListener method. When the action event occurs, that object's actionPerformed
 method is invoked.*\

JFrame f;/*The default behavior is to simply hide the JFrame when the user closes the window.a JFrame contains a JRootPane as its only child.*\
JButton b1,b2,b3,b4,b5,b6,b7;/*this package comes from swing*\
Reservation r;
Cancellation c;
JLabel imgL,imgL1,imgL2;/*JLabel object can display either text, an image, or both.*\
ImageIcon img,img1,img2;/*An implementation of the Icon interface that paints Icons from Images*\
String user;
PreparedStatement ps;/*The main feature of a PreparedStatement object is that, unlike a Statement object, it is given a SQL statement when it is created*\the 
main advantage is that this sql statement is sent to dbms right away,where it is compiled*\
Statement st;
ResultSet rs;
Main(String u)
{
user=u;
img=new ImageIcon("road_to_death_valley-t2.jpg");
imgL=new JLabel(img);
imgL.setBounds(0,0,1366,768);
f=new JFrame("Main");
f.getContentPane().setLayout(null);/*content pane is object created by java run time environment the content pane object 
then is substituted there so that you can apply a method to it.*\
f.getContentPane().setBackground(Color.black);
b1=new JButton("Reservation Form");
b1.addActionListener(this);
b1.setBounds(150,165,210,60);
b1.setBorder(new RoundedBorder(50));
b3=new JButton("Cancellation Form");
b3.addActionListener(this);
b3.setBounds(150,320,210,60);
b3.setBorder(new RoundedBorder(50));
 b4=new JButton("Exit");
b4.addActionListener(this);
b4.setBounds(950,490,210,60);
b4.setBorder(new RoundedBorder(50));
b5=new JButton("User History");
b5.addActionListener(this);
b5.setBounds(150,490,210,60);
b5.setBorder(new RoundedBorder(50));
b6=new JButton("Log Out");
b6.addActionListener(this);
b6.setBounds(950,165,210,60);
b6.setBorder(new RoundedBorder(50));
b7=new JButton("Find Busses");
b7.addActionListener(this);
b7.setBounds(950,350,210,60);
b7.setBorder(new RoundedBorder(50));
b1.setBackground(Color.lightGray);
b1.setForeground(new Color(0,0,0));
b3.setBackground(Color.lightGray);
b3.setForeground(new Color(0,0,0));
b4.setBackground(Color.lightGray);
b4.setForeground(new Color(0,0,0));
b5.setBackground(Color.lightGray);
b5.setForeground(new Color(0,0,0));
b6.setBackground(Color.lightGray);
b6.setForeground(new Color(0,0,0));
b7.setBackground(Color.lightGray);
b7.setForeground(new Color(0,0,0));
b1.setMnemonic('R');//Mnemonics allows user to interact with menu items using keys on keyboard.
b3.setMnemonic('C');//event-- If a user clicks on a button, clicks on a combo box, or types characters into a text field, etc.. then an event will trigger.
b4.setMnemonic('E');
b5.setMnemonic('H');
b6.setMnemonic('O');
b7.setMnemonic('F');
f.add(b1);
f.add(b3);
f.add(b4);
f.add(b5);
f.add(b6);
f.add(b7);
f.add(imgL);
f.setSize(1366,768);
f.setVisible(true);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)//An event object contains a reference to the component that generated the event. To extract that reference from the event object use:
{
f.setVisible(false);//it helps in changing the frame  
r=new Reservation(user);
}
if(e.getSource()==b3)
{
f.setVisible(false);
c=new Cancellation(user);
}
if(e.getSource()==b4)
{
f.setVisible(false);
System.exit(0);
}
if(e.getSource()==b6)
{
f.setVisible(false);
new Login();
}
if(e.getSource()==b7)
{
f.setVisible(false);
new Find(user);
}
if(e.getSource()==b5)
{
try
{
ps=con.prepareStatement("Select * From history where Username ='"+user+"'");
rs=ps.executeQuery();
String col[]={"Username","Ticket No.","Bus No.","No. of Passengers"};
String ar[][]=new String[50][4];
int x=0;
while(rs.next())
{
ar[x][0]=user;
ar[x][1]=(rs.getString("Ticket_No"));
ar[x][2]=(rs.getString("Bus_No"));
ar[x][3]=(rs.getString("Count"));
x++;
}
new Table(col,ar);
}
catch(Exception e1)
{
	System.out.println(e1);
}
}
}
class RoundedBorder implements Border 
{
int radius;
RoundedBorder(int radius) 
{
this.radius = radius;
}
public Insets getBorderInsets(Component c) {//border banana ka class hai,Returns the insets of the border.
return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
}
public boolean isBorderOpaque() {//Returns whether or not the border is opaque.
return true;
}
public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {/*Paints the border for the specified component with
 the specified position and size.*\
g.drawRoundRect(x,y,width-1,height-1,radius,radius);/*c - the component for which this border is being painted
g - the paint graphics
x - the x position of the painted border
y - the y position of the painted border
width - the width of the painted border
height - the height of the painted border*\
}
}
public static void main(String args[])
{
new Main("admin");
}
}