import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.geom.*;
class Find extends Connect implements ActionListener
{
int count=0;
JFrame f;
JLabel l1,l2;
JTextField t1,t2;
JButton b1,b2;
PreparedStatement ps;
ResultSet rs;
JLabel imgL;
ImageIcon img; 
String user;
int flag=0;
Find(String s)
{
user=s;
img=new ImageIcon("HD-wallpaper-volvo-bus-blue.jpg");
imgL=new JLabel(img);
imgL.setBounds(0,0,1300,768);
f=new JFrame("Find Bus");
f.getContentPane().setLayout(null);
f.getContentPane().setBackground(Color.black);
l1=new JLabel("From");
l1.setFont(new Font("Arial",(Font.BOLD),30));
l1.setForeground(Color.red);
l1.setBounds(50,55,200,50);
l2=new JLabel("To");
l2.setFont(new Font("Arial",(Font.BOLD),30));
l2.setForeground(Color.red);
l2.setBounds(50,100,200,50);
t1=new JTextField(16);
t1.addActionListener(this);
t1.setFont(new Font("Arial",(Font.BOLD),20));
t1.setBackground(Color.lightGray);
t1.setBounds(180,55,260,50);
t2=new JTextField(16);
t2.addActionListener(this);
t2.setFont(new Font("Arial",(Font.BOLD),20));
t2.setBackground(Color.lightGray);
t2.setBounds(180,100,260,50);
b1=new JButton("Search");
b1.setBackground(Color.darkGray);
b1.setForeground(Color.white);
b1.addActionListener(this);
b1.setBounds(90,250,100,50);
b1.setBorder(new RoundedBorder(30));
b2=new JButton("Back");
b2.setBackground(Color.darkGray);
b2.setForeground(Color.white);
b2.addActionListener(this);
b2.setBounds(270,250,100,50);
b2.setBorder(new RoundedBorder(30));
b1.setMnemonic('S');
b2.setMnemonic('B');
f.add(l1);
f.add(l2);
f.add(t1);
f.add(t2);
f.add(b1);
f.add(b2);
f.add(imgL);
f.setSize(1300,1000);
f.setVisible(true);
}
public void actionPerformed(ActionEvent e)
{
String [][] data= new String[20][2];
String [] column={"Bus No."};
if(t1.getText().length()!=0&&t2.getText().length()!=0&&e.getSource()==b1)
{
try
{
ps=con.prepareStatement("select * from bus where Source='"+t1.getText()+"'&&Destination='"+t2.getText()+"'");
rs=ps.executeQuery();
while(rs.next())
{
count++;
flag=1;
data[count-1][0]=rs.getString("Bus_no");
}
if(flag==0)
JOptionPane.showMessageDialog(null,"No Busses found");
else
new Table(column,data);
}
catch(Exception e1)
{
System.out.println("connection failed:"+e1);
}
}
if(e.getSource()==b2)
{
f.setVisible(false);
new Main(user);
}
}
class RoundedBorder implements Border 
{
int radius;
RoundedBorder(int radius) 
{
this.radius = radius;
}
public Insets getBorderInsets(Component c) {
return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
}
public boolean isBorderOpaque() {
return true;
}
public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
g.drawRoundRect(x,y,width-1,height-1,radius,radius);
}
}
public static void main(String args[])
{
new Find("admin");
}
}