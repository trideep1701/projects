import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class Login extends Connect implements ActionListener
{
JFrame f;
JLabel l1,l2,l3,l4,l5;
JTextField t1,t3;
JPasswordField t2;
PreparedStatement ps;
ResultSet rs;
Statement s;
JButton b1,b2,b3,b4,b5,b6;
String str;
Detail d;
ImageIcon image;
Main M;
Login()
{
image=new ImageIcon("BUS1.jpg");
l3=new JLabel(image);
l3.setBounds(0,0,1059,768);
f=new JFrame("Login");
f.getContentPane().setLayout(null);
f.getContentPane().setBackground(Color.black);
l1=new JLabel("User Name");
l1.setForeground(Color.red);
l1.setBounds(310,250,250,50);
l1.setFont(new Font("Arial Unicode MS",Font.BOLD,40));
l2=new JLabel("Password");
l2.setForeground(Color.red);
l2.setBounds(310,320,200,50);
l2.setFont(new Font("Arial Unicode MS",Font.BOLD,40));
str="";
int y;
for(int x=0;x<6;x++)
{
if((x%2)==0)
y=65+(int)(Math.random()*26);
else
y=48+(int)(Math.random()*10);
str=str+(char)y;
} 
l4=new JLabel("Captcha");
l4.setForeground(Color.red);
l4.setBounds(310,385,250,50);
l4.setFont(new Font("Arial Unicode MS",Font.BOLD,40));
l5=new JLabel(str);
l5.setForeground(Color.red);
l5.setBackground(Color.lightGray);
l5.setBounds(310,425,250,50);
l5.setFont(new Font("Arial Unicode MS",(Font.BOLD+Font.ITALIC),40));
t1=new JTextField(40);
t1.setForeground(Color.blue);
t1.setBounds(560,250,200,50);
t1.setFont(new Font("Arial Unicode MS",Font.BOLD,30));  
t2=new JPasswordField(40);
t2.setForeground(Color.blue);
t2.setEchoChar('*');
t2.setBounds(560,320,200,50);
t2.setFont(new Font("Arial Unicode MS",Font.BOLD,30));  
t3=new JTextField(40);
t3.setForeground(Color.blue);
t3.setBounds(560,390,200,50);
t3.setFont(new Font("Arial Unicode MS",Font.BOLD,30));  
b1=new JButton("Confirm");
b1.setForeground(Color.blue);
b1.addActionListener(this);
b1.setBounds(340,500,120,40);
b2=new JButton("Cancel");
b2.setForeground(Color.blue);
b2.addActionListener(this);
b2.setBounds(480,500,120,40);
b3=new JButton("Refresh");
b3.setForeground(Color.blue);
b3.addActionListener(this);
b3.setBounds(620,500,120,40);
b4=new JButton("Forgot ??");
b4.setForeground(Color.blue);
b4.setBounds(540,560,100,40);
b4.addActionListener(this);
b5=new JButton("Sign up");
b5.setForeground(Color.blue);
b5.setBounds(420,560,100,40);
b5.addActionListener(this);
b1.setMnemonic('O');
b2.setMnemonic('C');
b3.setMnemonic('R');
b4.setMnemonic('F');
b5.setMnemonic('S');
f.add(l1);
f.add(l2);
f.add(l4);
f.add(l5);
f.add(t1);
f.add(t2);
f.add(t3);
f.add(b1);
f.add(b2);
f.add(b3);
f.add(b4);
f.add(b5);
f.add(l3);
f.setBounds(0,0,1059,800);
f.setResizable(false);
f.setVisible(true);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
try
{
ps=con.prepareStatement("select * from sign_up where Username='"+t1.getText()+"' and Password='"+t2.getText()+"'");
rs=ps.executeQuery();
if(rs.next())
{
if(t3.getText().equals(str))
{
f.setVisible(false);
M=new Main(t1.getText());
}
else
{
JOptionPane.showMessageDialog(null,"Invalid Captcha ");
}
}
else {
JOptionPane.showMessageDialog(null,"Invalid User Name or Password");
}
}
catch(Exception e1)
{
System.out.println("Connection Failed"+e1);
}
}
if(e.getSource()==b2)
{
f.setVisible(false);
System.exit(0);
}
if(e.getSource()==b3)
{
Login l=new Login();
f.setVisible(false);
}
if(e.getSource()==b4)
{
f.setVisible(false);
d=new Detail();
}
if(e.getSource()==b5)
{
new Sign_up();
f.setVisible(false);
}
}
}