import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
class Cancellation extends Connect implements ActionListener
{
JFrame f;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
JTextField t1,t2,t3,t4,t5,t6,t7,t8;
JTextArea  ta;
JButton b1,b2,b3;
PreparedStatement ps,ps2;
ResultSet rs;
Statement st;
JLabel imgl;
ImageIcon img;
int count=1;
String user;
Cancellation(String u)
{
user=u;
f=new JFrame("Cancellation");
f.getContentPane().setLayout(null);
img=new ImageIcon("Setra_S416GT-HD_bus_from_Slovakia.jpg");
imgl=new JLabel(img);
imgl.setBounds(0,0,1366,768);
l1=new JLabel("Ticket No");
l1.setBounds(50,80,200,30);
l1.setFont(new Font("Cooper",Font.BOLD,20));
l1.setForeground(Color.yellow);
l2=new JLabel("Bus No");
l2.setBounds(50,130,200,30);
l2.setFont(new Font("Cooper",Font.BOLD,20));
l2.setForeground(Color.yellow);
l4=new JLabel("BusType ");
l4.setBounds(50,230,200,30);
l4.setFont(new Font("Cooper",Font.BOLD,20));
l4.setForeground(Color.yellow);
l5=new JLabel("Date of Journey");
l5.setBounds(50,280,200,30);
l5.setFont(new Font("Cooper",Font.BOLD,20));
l5.setForeground(Color.yellow);
b1=new JButton("Auto Fill");
b1.setBackground(Color.yellow);
b1.addActionListener(this);
b1.setBounds(150,430,100,40);
b2=new JButton("Cancel Ticket Now!");
b2.setBackground(Color.yellow);
b2.addActionListener(this);
b2.setBounds(280,430,180,40);
b3=new JButton("Back");
b3.setBackground(Color.yellow);
b3.addActionListener(this);
b3.setBounds(480,430,100,40);
b1.setMnemonic('O');
b2.setMnemonic('B');
t1=new JTextField(10);
t1.setBounds(230,80,100,30);
t2=new JTextField(10);
t2.addActionListener(this);
t2.setBounds(230,130,100,30);
t4=new JTextField(10);
t4.addActionListener(this);
t4.setBounds(230,230,100,30);
t5=new JTextField(10);
t5.addActionListener(this);
t5.setBounds(230,280,100,30);
f.add(l1);
f.add(l2);
f.add(l4);
f.add(l5);
f.add(b1);
f.add(b2);
f.add(b3);
f.add(t1);
f.add(t2);
f.add(t4);
f.add(t5);
f.add(imgl);
f.setSize(1300,1000);
f.setVisible(true);
}
public void actionPerformed(ActionEvent ae)
{
String [][] data= new String[20][8];
String [] column={"Name","Age","Category","Bus No.","Class","Date","Seat No."};
try
{
if(ae.getSource()==b1)
{
if(t1.getText().length()!=0)
{
ps=con.prepareStatement("Select * From details where Ticket_no ='"+t1.getText()+"'");
rs=ps.executeQuery();/*Execute Query is an operating system independent database utility written entirely in Java.
Execute Query provides a simple way to interact with almost any database from simple queries to table creation 
and import/export of an entire schema's data*\
if(rs.next())
{
t2.setText(rs.getString("Bus_no"));
t4.setText(rs.getString("Class"));
t5.setText(rs.getString("Date"));
}
else
{ 
t2.setText("");
t4.setText("");
t5.setText("");
JOptionPane.showMessageDialog(null,"Invalid Ticket number");
}
}
else
{
JOptionPane.showMessageDialog(null,"Enter Details!!");
}
}
}
catch(Exception e)
{
System.out.println("Connection Failed:"+e);
}
if(ae.getSource()==b2)
{
int ref=0;
try
{
if(t2.getText().length()!=0)
{
ps=con.prepareStatement("Select * From details where Ticket_no ='"+t1.getText()+"'");
rs=ps.executeQuery();
while(rs.next())
{
data[count-1][0]=rs.getString("Name");
data[count-1][1]=rs.getString("Age");
data[count-1][2]=rs.getString("Category");
data[count-1][3]=rs.getString("Bus_no");
data[count-1][4]=rs.getString("Class");
data[count-1][5]=rs.getString("Date");
data[count-1][6]=Integer.toString(rs.getInt("Seat_No"));
data[count-1][7]="Cancelled";
ref+=rs.getInt("rate");
count++;
}
ref=(int)(ref*0.75);
new Table(column,data);
ps=con.prepareStatement("delete from details where Ticket_no='"+t1.getText()+"'");
ps.executeUpdate();
ps2=con.prepareStatement("delete from history where Ticket_no='"+t1.getText()+"'");
ps2.executeUpdate();
JOptionPane.showMessageDialog(null,"Reservation Cancelled\n Money Refunded:-  "+ref);
f.setVisible(false);
new Main(user);
}
else
{JOptionPane.showMessageDialog(null,"Enter Details!!");}
}
catch(Exception e1)
{
System.out.println("Connection failed:"+e1);
}
}
if(ae.getSource()==b3)
{
f.setVisible(false);
new Main(user);
}
}
public static void main(String args[])
{
new Cancellation("admin");
}
}

