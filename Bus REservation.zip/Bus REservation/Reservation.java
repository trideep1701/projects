import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class Reservation extends Connect implements ActionListener
{
JFrame f;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JTextField t1,t2,t3,t4,t5,t6;
Choice h;
CheckboxGroup cg;
Checkbox c1,c2;
JButton b1,b2,b3;
PreparedStatement ps;
Statement st;
ResultSet rs;
int x;
JLabel imgL;
ImageIcon img;
String str,str2,user;
void disable()
{
t3.setEnabled(false);
t4.setEnabled(false);
t5.setEnabled(false);
}
void enable()
{
t3.setEnabled(true);
t4.setEnabled(true);
t5.setEnabled(true);
}
Reservation(String u)
{
user=u;
img=new ImageIcon("5602.jpg");
imgL=new JLabel(img);
imgL.setBounds(0,0,1300,768);
f=new JFrame("Reservation");
f.getContentPane().setLayout(null);
f.getContentPane().setBackground(Color.lightGray);
l1=new JLabel("Bus Number");
l1.setBounds(400,150,150,30);
l1.setFont(new Font("Cooper",Font.BOLD,20));
l1.setForeground(Color.yellow);
l3=new JLabel("Bus Type");
l3.setBounds(400,250,150,30);
l3.setFont(new Font("Cooper",Font.BOLD,20));
l3.setForeground(Color.yellow);
l4=new JLabel("Date of Journey");
l4.setBounds(400,300,170,30);
l4.setFont(new Font("Cooper",Font.BOLD,20));
l4.setForeground(Color.yellow);
l8=new JLabel("(dd-mm-yyyy)");
l8.setBounds(710,300,170,30);
l8.setFont(new Font("Cooper",Font.BOLD,20));
l8.setForeground(Color.yellow);
l5=new JLabel("From");
l5.setBounds(400,350,100,30);
l5.setFont(new Font("Cooper",Font.BOLD,20));
l6=new JLabel("To");
l6.setBounds(570,350,50,30);
l6.setFont(new Font("Cooper",Font.BOLD,20));
l6.setForeground(Color.yellow);
t1=new JTextField(10);
t1.setBounds(600,150,100,30);
cg=new CheckboxGroup();
c1=new Checkbox("A/C",cg,true);
c1.setBounds(600,250,80,30);
c1.setFont(new Font("Cooper",Font.BOLD,15));
c1.setBackground(Color.lightGray);
c2=new Checkbox("Sleeper",cg,false); 
c2.setBounds(700,250,80,30);
c2.setFont(new Font("Cooper",Font.BOLD,15));
c2.setBackground(Color.lightGray);
t3=new JTextField(10);
t3.setBounds(600,300,100,30);
t4=new JTextField(10);
t4.setBounds(460,350,100,30);
t5=new JTextField(10);
t5.setBounds(600,350,100,30);
b1=new JButton("Auto-Fill");
b1.setBackground(Color.lightGray);
b1.setBounds(300,500,150,40);
b1.setFont(new Font("Arial",Font.BOLD,20));
b1.addActionListener(this);
b2=new JButton("Next");
b2.setBackground(Color.lightGray);
b2.setBounds(475,500,150,40);
b2.setFont(new Font("Arial",Font.BOLD,20));
b2.addActionListener(this);
b3=new JButton("Main");
b3.setBackground(Color.lightGray);
b3.setBounds(650,500,150,40);
b3.setFont(new Font("Arial",Font.BOLD,20));
b3.addActionListener(this);
b1.setMnemonic('I');
b2.setMnemonic('N');
b3.setMnemonic('M');
f.add(l1);
f.add(l3);
f.add(l4);
f.add(l5);
f.add(l6);
f.add(l8);
f.add(t1);
f.add(t3);
f.add(t4);
f.add(t5);
f.add(c1);
f.add(c2);
f.add(b1);
f.add(b2);
f.add(b3);
f.add(imgL);
f.setSize(1300,1000);
f.setVisible(true);
disable();
}
public void actionPerformed(ActionEvent ae)
{
String[] ar=new String[9];
String cost;	
enable();
try
{
t1.setEnabled(true);
if(t1.getText().length()!=0&&ae.getSource()==b1)
{
ps=con.prepareStatement("Select * From bus where Bus_no='"+t1.getText()+"'");
rs=ps.executeQuery();
if(rs.next())
{
t4.setText(rs.getString("Source"));
t5.setText(rs.getString("Destination"));
}
else
{ 
t4.setText("");
t5.setText("");
JOptionPane.showMessageDialog(null,"Invalid Bus number");
}
}
if(ae.getSource()==b2)
{
Calendar c= Calendar.getInstance();
Calendar c1=Calendar.getInstance();
c.get(Calendar.DATE);
c.get(Calendar.MONTH);
c.get(Calendar.YEAR);
String DOJ=t3.getText();
String []s1=DOJ.split("\\-");
int n=s1.length;
int x[]=new int[n];
int flag=0;
try
{
for(int i=0;i<n;i++)
{
x[i]=Integer.parseInt(s1[i]);
}
c1.set(Calendar.DATE,x[0]);
c1.set(Calendar.MONTH,x[1]);
c1.set(Calendar.YEAR,x[2]);
if(!(x[0]>=0&&x[0]<=31))
flag++;
if(!(x[1]>=1&&x[1]<=12))
flag++;
}
catch(NumberFormatException e)
{
flag++;
}
if (t1.getText().length()==0||/*t2.getText().length()==0||*/t3.getText().length()==0||t4.getText().length()==0||t5.getText().length()==0/*||t6.getText().length()==0*/)
{
JOptionPane.showMessageDialog(null,"You didn't fill all the required fields .Sorry!!! You can't proceed . Try again");
}
else
{
if (c1.before(c)||flag!=0)
{
JOptionPane.showMessageDialog(null,"Date expired .Sorry !!! Try again");
}
else 
{
int p=0;
p=10000000+(int)(Math.random()*(99999999-10000000+1));
ar[0]=Integer.toString(p);
ar[1]=t1.getText();
ar[3]=cg.getSelectedCheckbox().getLabel();
ar[4]=t3.getText();
ar[6]=str;
ar[7]=str2;
if(cg.getSelectedCheckbox().getLabel().equals("A/C"))
cost="2000.00";
else
cost="800.00";
ar[8]=cost;
new Passenger(ar,0,user,0);
f.setVisible(false);
}
}
}
if(ae.getSource()==b3)
{
f.setVisible(false);
new Main(user);
}
}
catch(SQLException e)
{
JOptionPane.showMessageDialog(null,"Invalid Bus number");
System.out.println("Error in connection "+e);
}
} 
public static void main(String args[])
{
new Reservation("admin");
}
}