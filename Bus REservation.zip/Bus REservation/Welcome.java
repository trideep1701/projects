import java.awt.*;
import javax.swing.*;
import java.net.URL;//it can be a reference to a more complicated object, such as a query to a database or to a search engine.
import javax.sound.sampled.*;
class Welcome implements Runnable/*Runnable is an interface and defines only one method called run(). When a Thread is started in Java by using Thread.start() 
method it calls run() method of Runnable task which was passed to Thread during creation. Code written inside run() method is executed by this newly created thread.*\ 
{
JFrame f;
JLabel l1,l2,l3,l4;
Thread t;
ImageIcon img;
Welcome()
{
img=new ImageIcon("random-wallpapers-road-background-wallpaper-wallpaper-31203.jpg");
System.out.println(img);
t=new Thread(this);
f=new JFrame("Welcome");
f.getContentPane().setLayout(null);
f.getContentPane().setBackground(Color.black);
l1=new JLabel("Online Bus Reservation");
l1.setBounds(600,100,1300,100);
l1.setFont(new Font("Arial Unicode MS",(Font.BOLD),60));
l1.setForeground(Color.red);
l2=new JLabel("By:- Trideep Raj,Shrey Agarwal");
l2.setFont(new Font("Arial Unicode MS",(Font.BOLD),60));
l2.setBounds(180,250,1300,200);
l2.setForeground(Color.yellow);
l3=new JLabel(img);
l3.setBounds(0,0,1300,768);/*Thread in Java is an independent path of execution which 
is used to run two task in parallel. When two Threads run in parallel that is called multi-threading in Java*\
f.add(l1);
f.add(l2);
f.add(l3);
f.setSize(1300,768);
f.setVisible(true);
t.start();
}
public void run()
{
int x=1;
while(x<=5)
{
try
{
Thread.sleep(1000);/*Thread.sleep causes the current thread to suspend execution for a specified period. This is an efficient means of making processor time available 
to the other threads of an application or other applications that might be running on a computer system*\
}
catch(Exception e)
{}
x++;
}
f.setVisible(false);
new Login();
}
}

