import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.util.*;
class Passenger extends Connect implements ActionListener
{
JFrame f;
JLabel l1,l2,l3,l4,l5,l6;
JTextField t1,t2,t3;
JButton b1,b2,b3;
CheckboxGroup cbg,cbg2;
Checkbox c1,c2,c3,c4,c5,c6,c7;
JTextArea ta;
PreparedStatement ps,ps2;
Statement st;
ResultSet rs;
JLabel imgL;
ImageIcon img;
String[] ar;
int count,seat;
double rate,rate1;
boolean b[]=new boolean[99];
int money;
String user;
Passenger(String[] ar1,int m,String u,int c)
{
img=new ImageIcon("bridge.png");
imgL=new JLabel(img);
imgL.setBounds(0,0,1366,768);
f=new JFrame("Passenger");
f.getContentPane().setLayout(null);
l1=new JLabel("Name of Passenger");
l1.setBounds(50,120,200,30);
l1.setForeground(Color.white);
l1.setFont(new Font("Cooper",Font.BOLD,20));
t1=new JTextField(10);
t1.setBounds(270,120,180,30);
l2=new JLabel("Age");
l2.setBounds(50,170,100,30);
l2.setForeground(Color.white);
l2.setFont(new Font("Cooper",Font.BOLD,20));
t2=new JTextField(10);
t2.setBounds(270,170,50,30);
l3=new JLabel("Gender");
l3.setBounds(50,220,100,30);
l3.setForeground(Color.white);
l3.setFont(new Font("Cooper",Font.BOLD,20));
ta=new JTextArea(5,10);
ta.setBounds(150,270,200,100);
l4=new JLabel("Address");
l4.setBounds(50,270,100,30);
l4.setForeground(Color.white);
l4.setFont(new Font("Cooper",Font.BOLD,20));
l5=new JLabel("Category");
l5.setBounds(50,400,100,30);
l5.setForeground(Color.white);
l5.setFont(new Font("Cooper",Font.BOLD,20));
b1=new JButton("Add More Passengers");
b1.setBackground(Color.yellow);
b1.addActionListener(this);
b1.setBounds(170,450,170,30);
b2=new JButton("Proceed");
b2.setBackground(Color.yellow);
b2.addActionListener(this);
b2.setBounds(370,450,100,30);
b3=new JButton("Back");
b3.setBackground(Color.yellow);
b3.addActionListener(this);
b3.setBounds(510,450,100,30);
b1.setMnemonic('M');//Mnemonics allows user to interact with menu items using keys on keyboard.
b2.setMnemonic('S');
b3.setMnemonic('B');
cbg=new CheckboxGroup();
cbg2=new CheckboxGroup();
c1=new Checkbox("Male",cbg,true);
c1.setBounds(150,220,100,30);
c1.setFont(new Font("Cooper",Font.BOLD,16));
c2=new Checkbox("Female",cbg,false); 
c2.setBounds(270,220,100,30);
c2.setFont(new Font("Cooper",Font.BOLD,16));
c3=new Checkbox("General",cbg2,true);
c3.setBounds(150,400,100,30);
c3.setFont(new Font("Cooper",Font.BOLD,16));
c4=new Checkbox("Senior Citizen",cbg2,false);
c4.setBounds(260,400,130,30);
c4.setFont(new Font("Cooper",Font.BOLD,16));
c5=new Checkbox("Ex-serviceman",cbg2,false);
c5.setBounds(400,400,130,30);
c5.setFont(new Font("Cooper",Font.BOLD,16));
c6=new Checkbox("Physically Challenged",cbg2,false);
c6.setBounds(540,400,200,30);
c6.setFont(new Font("Cooper",Font.BOLD,16));
c7=new Checkbox("Woman",cbg2,false);
c7.setBounds(750,400,100,30);
c7.setFont(new Font("Cooper",Font.BOLD,16));
ar=ar1;money=m;count=c;
user=u;
f.add(l1);
f.add(l2);
f.add(l3);
f.add(l4);
f.add(l5);
f.add(t1);
f.add(t2);
f.add(ta);
f.add(b1);
f.add(b2);
f.add(b3);
f.add(c1);
f.add(c2);
f.add(c3);
f.add(c4);
f.add(c5);
f.add(c6);
f.add(c7);
f.add(imgL);
f.setSize(1300,1000);
f.setVisible(true);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{

if(t1.getText().length()!=0&&t2.getText().length()!=0&&ta.getText().length()!=0)
{

b1.setEnabled(true);
try
{
rate=Double.parseDouble(ar[8]);
String cat="";
ps=con.prepareStatement("insert into details values (?,?,?,?,?,?,?,?,?,?,?)");
ps.setString(1,ar[0]);
ps.setString(2,t1.getText());
ps.setString(3,t2.getText());
ps.setString(4,cbg.getSelectedCheckbox().getLabel());
ps.setString(5,ta.getText());
ps.setString(6,cbg2.getSelectedCheckbox().getLabel());
ps.setString(7,ar[1]);
ps.setString(8,ar[3]);
ps.setString(9,ar[4]);
ps.setString(11,ar[7]);
seat=1+(int)(Math.random()*(99));
ps.setInt(10,seat);
int x=0;
if(cbg2.getSelectedCheckbox().getLabel().equals("Senior Citizen"))
{
rate1=rate-0.5*(rate);
ps.setDouble(11,rate1);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Ex-serviceman"))
{
rate1=rate-0.2*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Physically Challenged"))
{
rate1=rate-0.3*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Woman"))
{
rate1=rate-0.1*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("General"))
{
rate1=rate;
}
x=(int)rate1;
ps.setInt(11,x);
ps.executeUpdate();
ps.close();
count++;
Passenger P=new Passenger(ar,money+x,user,count);
f.setVisible(false);
}
catch(Exception e1)
{
System.out.println("Connection failed:"+e1);
}
}
else
{
JOptionPane.showMessageDialog(null,"Enter All Details..!");
}
}
if(e.getSource()==b2)
{
if(t1.getText().length()!=0&&t2.getText().length()!=0&&ta.getText().length()!=0)
{
try
{
String cat="";
ps=con.prepareStatement("insert into details values(?,?,?,?,?,?,?,?,?,?,?)");
ps.setString(1,ar[0]);
ps.setString(2,t1.getText());
ps.setString(3,t2.getText());
ps.setString(4,cbg.getSelectedCheckbox().getLabel());
ps.setString(5,ta.getText());
ps.setString(6,cbg2.getSelectedCheckbox().getLabel());
ps.setString(7,ar[1]);
ps.setString(8,ar[3]);
ps.setString(9,ar[4]);
ps.setString(10,ar[4]);
ps.setString(11,ar[7]);
seat=1+(int)(Math.random()*(99));
ps.setInt(10,seat);
rate=Double.parseDouble(ar[8]);
int x=0;
if(cbg2.getSelectedCheckbox().getLabel().equals("Senior Citizen"))
{
rate1=rate-0.5*(rate);
ps.setDouble(11,rate1);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Ex-serviceman"))
{
rate1=rate-0.2*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Physically Challenged"))
{
rate1=rate-0.3*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("Woman"))
{
rate1=rate-0.1*(rate);
}
else if(cbg2.getSelectedCheckbox().getLabel().equals("General"))
{
rate1=rate;
}
x=(int)rate1;
ps.setInt(11,x);
ps.executeUpdate();
ps.close();
money+=x;
st=con.createStatement();
rs=st.executeQuery("select * from details");
count++;
ps2=con.prepareStatement("insert into history values (?,?,?,?,?,?)");
ps2.setString(1,user);
ps2.setString(2,ar[0]);
Calendar c= Calendar.getInstance();
String d="";
d=d+c.get(Calendar.DATE)+"-";
d=d+(c.get(Calendar.MONTH)+1)+"-";
d=d+c.get(Calendar.YEAR);
ps2.setString(3,d);
ps2.setString(4,ar[1]);
ps2.setString(5,ar[2]);
ps2.setString(6,Integer.toString(count));
ps2.executeUpdate();
ps2.close();
JOptionPane.showMessageDialog(null,"Record Saved\nYour Ticket No. is:-  "+ar[0]+"\nAmount to be paid:-  "+money);
b2.setEnabled(false);
b1.setEnabled(false);
st.close();
f.setVisible(false);
new Main(user);
}
catch(Exception e1)
{
System.out.println("Connection failed:"+e1);
}
}
else
{
	JOptionPane.showMessageDialog(null,"Enter All Details..!");
}
}
if(e.getSource()==b3)
{
f.setVisible(false);
new Reservation(user);
}
}
public static void main(String[] args)
{
new Passenger(args,0," ",0);
}
}