import java.sql.*;
public class Connect
{
public Connection con;
public Connect()
{
try
{
Class.forName("com.mysql.jdbc.Driver").newInstance();
con=DriverManager.getConnection("jdbc:mysql://localhost/Busses?"+"user=root");
}
catch(Exception e1)
{
System.out.println("Connection Failed:"+e1);   
}
}
} 