import javax.swing.*;
import java.awt.*;
 public class Table {
    public Table(String[] columns,String [][] data) {
        final JFrame frame = new JFrame("Details");//You can find task-oriented documentation about using JFrame in The Java
 
        JTable table = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);
           frame.getContentPane().setLayout(new BorderLayout());
       frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
        frame.setSize(800,150);
        frame.setVisible(true);/*--The JRootPane instance that manages the contentPane and optional menuBar for this frame, 
as well as the glassPane.*\
    }
}